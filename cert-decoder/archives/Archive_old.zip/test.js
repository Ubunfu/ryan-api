	const x509 = require('x509');
	// Decode the certificate using the request body
	const decodedCert = x509.parseCert(__dirname + '/certString.pem');
	// const decodedCert = x509.parseCert(__dirname + '/cert.pem');

	console.log(decodedCert);
